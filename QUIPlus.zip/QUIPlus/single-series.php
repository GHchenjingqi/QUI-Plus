<?php get_header();?> 
<?php get_template_part( QUI_ThemePath().'/series' );?>
<?php get_footer(); ?>