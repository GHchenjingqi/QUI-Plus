<?php get_header();?> 
<?php get_template_part( QUI_ThemePath().'/page' );?>
<?php get_footer(); ?>