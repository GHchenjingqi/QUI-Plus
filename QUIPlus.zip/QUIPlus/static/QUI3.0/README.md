# QUI
QUI插件整合了前端常用的JS方法及CSS基础样式

## QUI.js
QUI.js是一款开源的前端轻量UI插件，能与JQuery,Swiper,Vue,Bootstraps,小程序,Wordpress等框架轻松耦合，尽量减少前端造轮子。QUI集成了ES6，HTML5，AJAX,QRcode等JS常用API方法。

### 公共方法

#### 生成二维码
createQRcode()

#### 获取盒子大小位置
getBoxRect()