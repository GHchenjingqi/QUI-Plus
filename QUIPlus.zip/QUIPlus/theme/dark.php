body{
		--BGColor:#333;
		--listBGColor:transparent;
		--hoverBG:#000;
		--defTXTCor:#fff;
		--menuTXTCor:#ccc;
		--menuBG:#565656;
		--menuBtnBG:#111;
		--menuBtnCor:#ccc;
		--listTXTCor:#ccc;
		--tabBtnBG:#111;
		--borderLineBG:#3e3e3e;
}
.bgff{background:transparent}
footer,.list-box ul li:not(.ui-card):hover{background:var(--listBGColor)}
footer div span, footer div a,footer div ,.ui-pagelink, .ui-relate-list,.ui-post-tags,.list-class{ color: var(--menuTXTCor);}
.ui-post{color:#bcbcbc}
.ui-post-tags a,.ui-title, .widget-title, .wp-block-search__label{border-color:#777;}
.ui-pagelink .col2 img{opacity:.1}
.widget-title,h1, h2, h3, h4, h5, h6{color:#fff}
