<?php

?>
<aside style="width:800px;margin:100px auto 0 auto;text-align:center">
<h1>请登录后台，切换至 Sky主题 </h1>
<p>pure主题正在开发中，登录后台：<a href="/wp-admin/admin.php?page=QUITheme#tab=基础设置" target="_self">点击前往</a></p>
</aside>