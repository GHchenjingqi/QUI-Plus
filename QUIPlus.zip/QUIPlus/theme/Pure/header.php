<link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_url').QUI_ThemePath().'static/style.css';?>"/>
</head>
<body>