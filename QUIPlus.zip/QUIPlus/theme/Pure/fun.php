<?php 
	//Pure子主题配置文件,字主题配置请添加到此
	//菜单
	register_nav_menus( array('QuiMenuTop' => 'PC头部导航','QuiMenuBottom' => 'Wap底部导航') );
	
	
?>