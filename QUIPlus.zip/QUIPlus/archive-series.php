<?php get_header(); ?>
	
<?php get_template_part( QUI_ThemePath().'/archive-series' );?>
	
<?php get_footer(); ?>