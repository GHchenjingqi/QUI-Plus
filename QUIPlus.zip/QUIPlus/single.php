<?php get_header();?> 
<?php get_template_part( QUI_ThemePath().'/single' );?>
<?php get_footer(); ?>