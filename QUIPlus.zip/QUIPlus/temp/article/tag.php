<?php if(get_the_tag_list()) {
	echo get_the_tag_list('<section class="ui-post-tags padding-lr" id="ui-tags"><p>TAGS:','','</p></section>');
} ?>