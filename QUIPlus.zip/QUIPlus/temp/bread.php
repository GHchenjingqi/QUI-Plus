<aside class="ui-bread text-h1">当前位置：<a href="<?php bloginfo('url'); ?>">首页</a> / <?php  QUI_Breadcrumb(); ?></aside>  
 