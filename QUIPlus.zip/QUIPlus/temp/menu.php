<menu class="ui-menu">
 <?php if(function_exists('wp_nav_menu')) wp_nav_menu(array('container' => false, 'theme_location' => 'QuiMenuTop')); ?>
</menu>