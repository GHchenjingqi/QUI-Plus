<?php
/*Template Name:首页推荐模板*/
?>
<?php get_header(); ?>
	
<?php get_template_part( QUI_ThemePath().'/index_top' );?>
	
<?php get_footer(); ?>