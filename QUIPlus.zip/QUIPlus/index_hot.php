<?php
/*Template Name:首页最热模板*/
?>
<?php get_header(); ?>
	
<?php get_template_part( QUI_ThemePath().'/index_hot' );?>
	
<?php get_footer(); ?>