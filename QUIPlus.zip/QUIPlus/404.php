<?php get_header(); ?>
	
<?php get_template_part( QUI_ThemePath().'/404' );?>
	
<?php get_footer(); ?>