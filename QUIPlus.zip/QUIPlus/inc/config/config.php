<?php
  require_once get_theme_file_path() .'/inc/config/config-basic.php';
  require_once get_theme_file_path() .'/inc/config/config-list.php';
  require_once get_theme_file_path() .'/inc/config/config-layer.php';
  require_once get_theme_file_path() .'/inc/config/config-banner.php';
  require_once get_theme_file_path() .'/inc/config/config-seo.php';
  require_once get_theme_file_path() .'/inc/config/config-tool.php';
  require_once get_theme_file_path() .'/inc/config/config-qrcode.php';
  require_once get_theme_file_path() .'/inc/config/config-boom.php';
  require_once get_theme_file_path() .'/inc/config/config-active.php';	
  //二期
  require_once get_theme_file_path() .'/inc/config/config-theme.php';
  require_once get_theme_file_path() .'/inc/config/config-article.php';
  //三期
  require_once get_theme_file_path() .'/inc/config/config-binfit.php';
?>