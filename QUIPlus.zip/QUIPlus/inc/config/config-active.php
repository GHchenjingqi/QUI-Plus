<?php
	//激活配置
	$setAct = array(
		array( 
	      'id'    => 'set-ActiveCode', 
	      'type'  => 'code', 
	      'title' => '主题状态', 
	      'before' => '主题激活码输入后，请点击“激活”按钮！',
      	)
    );
?>