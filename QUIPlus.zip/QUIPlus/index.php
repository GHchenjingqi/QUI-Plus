<?php get_header(); ?> 
<?php get_template_part( QUI_ThemePath().'/index' );?>
<?php get_footer(); ?>