<?php  
	/* QUI主题 核心文件*/
	require_once get_theme_file_path() .'/inc/function.php';
	require_once get_theme_file_path() .'/inc/inc-value.php';
	require_once get_theme_file_path().QUI_ThemePath().'fun.php';
?>



